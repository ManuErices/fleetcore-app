// src/App.jsx
import { useState } from 'react'
import { getSession } from './lib/auth.js'
import Login from './pages/Login.jsx'
import Layout from './components/Layout.jsx'
import PlanTrabajo from './pages/PlanTrabajo.jsx'
import InformeDiario from './pages/InformeDiario.jsx'
import Historial from './pages/Historial.jsx'

export default function App() {
  const [session, setSession] = useState(() => getSession())
  const [page,    setPage]    = useState('plan')

  if (!session) return <Login onLogin={setSession}/>

  const pages = {
    plan:      <PlanTrabajo  session={session}/>,
    informe:   <InformeDiario session={session}/>,
    historial: <Historial/>,
  }

  return (
    <Layout session={session} page={page} onNavigate={setPage}>
      {pages[page] || pages.plan}
    </Layout>
  )
}
