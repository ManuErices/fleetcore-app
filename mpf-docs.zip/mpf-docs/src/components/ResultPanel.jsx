// src/components/ResultPanel.jsx
import { useState } from 'react'
import { guardarDocumento } from '../lib/documentos.js'

export default function ResultPanel({ texto, tipo, titulo, session, onSaved }) {
  const [copied, setCopied]   = useState(false)
  const [saving, setSaving]   = useState(false)
  const [saved, setSaved]     = useState(false)

  async function copiar() {
    await navigator.clipboard.writeText(texto)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  async function guardar() {
    setSaving(true)
    try {
      await guardarDocumento({
        tipo, titulo, contenido: texto,
        usuario: session.usuario,
        nombre: session.nombre,
      })
      setSaved(true)
      onSaved?.()
    } catch (e) {
      alert('Error al guardar: ' + e.message)
    }
    setSaving(false)
  }

  if (!texto) return null

  return (
    <div className="card" style={{ marginTop: '1.5rem' }}>
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        paddingBottom: 12, marginBottom: 16, borderBottom: '1px solid var(--gray-200)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 11, fontWeight: 600, textTransform: 'uppercase',
            letterSpacing: '.05em', color: 'var(--gray-600)' }}>
            Documento generado
          </span>
          <span className="badge badge-green">✓ Listo</span>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button className="btn btn-outline btn-sm" onClick={copiar}>
            {copied ? '¡Copiado!' : 'Copiar'}
          </button>
          <button
            className="btn btn-primary btn-sm" onClick={guardar}
            disabled={saving || saved}
          >
            {saved ? '✓ Guardado' : saving ? 'Guardando…' : 'Guardar en historial'}
          </button>
        </div>
      </div>
      <pre style={{
        whiteSpace: 'pre-wrap', fontSize: 13.5, lineHeight: 1.9,
        color: 'var(--gray-800)', fontFamily: 'inherit',
        maxHeight: 560, overflowY: 'auto', paddingRight: 4,
      }}>
        {texto}
      </pre>
    </div>
  )
}
