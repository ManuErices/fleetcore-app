// src/components/Layout.jsx
import { useState } from 'react'
import { logout } from '../lib/auth.js'

const NAV = [
  { id: 'plan',     label: 'Plan de Trabajo',    icon: '📋' },
  { id: 'informe',  label: 'Informe Diario',      icon: '📝' },
  { id: 'historial',label: 'Historial',            icon: '🗂️' },
]

export default function Layout({ session, page, onNavigate, children }) {
  const [sideOpen, setSideOpen] = useState(false)

  function handleLogout() {
    logout()
    window.location.reload()
  }

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>

      {/* Overlay mobile */}
      {sideOpen && (
        <div onClick={() => setSideOpen(false)} style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,.4)',
          zIndex: 40, display: 'none',
        }} className="mobile-overlay"/>
      )}

      {/* Sidebar */}
      <aside style={{
        width: 240, background: '#0f2035', display: 'flex',
        flexDirection: 'column', flexShrink: 0,
        position: 'sticky', top: 0, height: '100vh',
      }}>
        {/* Header */}
        <div style={{
          padding: '1.25rem 1rem', borderBottom: '1px solid rgba(255,255,255,.08)',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <div style={{
            width: 36, height: 36, background: 'rgba(255,255,255,.12)',
            borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center',
            border: '1px solid rgba(255,255,255,.15)', flexShrink: 0,
          }}>
            <svg width="20" height="20" viewBox="0 0 32 32" fill="none">
              <path d="M16 3L28 8v8c0 7-5.5 12.5-12 14C9.5 28.5 4 23 4 16V8L16 3z"
                fill="rgba(255,255,255,.2)" stroke="rgba(255,255,255,.5)" strokeWidth="1.5"/>
              <text x="16" y="21" textAnchor="middle" fill="white" fontSize="8"
                fontWeight="700" fontFamily="system-ui">MPF</text>
            </svg>
          </div>
          <div>
            <div style={{ color: '#fff', fontSize: 14, fontWeight: 600 }}>MPF Documentos</div>
            <div style={{ color: 'rgba(255,255,255,.4)', fontSize: 11 }}>Río Tinto</div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: '0.75rem 0.5rem' }}>
          {NAV.map(item => (
            <button
              key={item.id}
              onClick={() => { onNavigate(item.id); setSideOpen(false) }}
              style={{
                width: '100%', display: 'flex', alignItems: 'center', gap: 10,
                padding: '9px 12px', borderRadius: 8, border: 'none',
                background: page === item.id ? 'rgba(255,255,255,.12)' : 'transparent',
                color: page === item.id ? '#fff' : 'rgba(255,255,255,.55)',
                fontSize: 13, fontWeight: page === item.id ? 500 : 400,
                cursor: 'pointer', marginBottom: 2, textAlign: 'left',
                transition: 'all .15s',
              }}
            >
              <span style={{ fontSize: 15 }}>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>

        {/* User */}
        <div style={{
          padding: '0.75rem', borderTop: '1px solid rgba(255,255,255,.08)',
        }}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '8px 10px', borderRadius: 8,
            background: 'rgba(255,255,255,.06)',
          }}>
            <div style={{
              width: 30, height: 30, borderRadius: '50%',
              background: 'rgba(255,255,255,.15)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#fff', fontSize: 12, fontWeight: 600, flexShrink: 0,
            }}>
              {session.nombre.charAt(0).toUpperCase()}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ color: '#fff', fontSize: 12, fontWeight: 500, 
                whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {session.nombre}
              </div>
              <div style={{ color: 'rgba(255,255,255,.4)', fontSize: 11 }}>
                {session.usuario}
              </div>
            </div>
            <button onClick={handleLogout} title="Cerrar sesión" style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'rgba(255,255,255,.4)', fontSize: 16, padding: 2, flexShrink: 0,
            }}>⎋</button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main style={{ flex: 1, padding: '2rem', maxWidth: 860, overflowX: 'hidden' }}>
        {children}
      </main>
    </div>
  )
}
