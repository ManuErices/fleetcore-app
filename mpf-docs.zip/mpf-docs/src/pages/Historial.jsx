// src/pages/Historial.jsx
import { useState, useEffect } from 'react'
import { obtenerDocumentos } from '../lib/documentos.js'

const TIPO_LABEL = { plan: 'Plan de Trabajo', informe: 'Informe Diario' }
const TIPO_COLOR = { plan: 'badge-navy', informe: 'badge-green' }

export default function Historial() {
  const [docs,    setDocs]    = useState([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState(null)
  const [error,   setError]   = useState('')

  useEffect(() => { cargar() }, [])

  async function cargar() {
    setLoading(true)
    setError('')
    try {
      const data = await obtenerDocumentos(60)
      setDocs(data)
    } catch(e) {
      setError('No se pudo cargar el historial. Revisa la conexión a Firebase.')
    }
    setLoading(false)
  }

  function formatFecha(ts) {
    if (!ts) return '–'
    const d = ts.toDate ? ts.toDate() : new Date(ts)
    return d.toLocaleDateString('es-CL', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' })
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem' }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 600, marginBottom: 4 }}>Historial de Documentos</h1>
          <p style={{ color: 'var(--gray-600)', fontSize: 14 }}>
            {docs.length} documento{docs.length !== 1 ? 's' : ''} guardado{docs.length !== 1 ? 's' : ''}
          </p>
        </div>
        <button className="btn btn-outline btn-sm" onClick={cargar} disabled={loading}>
          {loading ? '…' : '↺ Actualizar'}
        </button>
      </div>

      {error && (
        <div style={{
          background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 8,
          padding: '12px 16px', color: 'var(--danger)', fontSize: 14, marginBottom: '1rem',
        }}>{error}</div>
      )}

      {loading ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--gray-400)' }}>
          <span className="dots" style={{ justifyContent: 'center' }}>
            <span className="dot"/><span className="dot"/><span className="dot"/>
          </span>
          <div style={{ marginTop: 12, fontSize: 14 }}>Cargando historial...</div>
        </div>
      ) : docs.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '3rem', color: 'var(--gray-400)' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>🗂️</div>
          <div style={{ fontSize: 15, fontWeight: 500 }}>Sin documentos aún</div>
          <div style={{ fontSize: 13, marginTop: 6 }}>
            Los documentos generados y guardados aparecerán aquí.
          </div>
        </div>
      ) : (
        <div style={{ display: 'grid', gap: 8 }}>
          {docs.map(doc => (
            <div key={doc.id} className="card" style={{
              cursor: 'pointer', transition: 'border-color .15s',
              borderColor: selected?.id === doc.id ? 'var(--navy)' : 'var(--gray-200)',
            }}
              onClick={() => setSelected(selected?.id === doc.id ? null : doc)}
            >
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                    <span className={`badge ${TIPO_COLOR[doc.tipo] || 'badge-gray'}`}>
                      {TIPO_LABEL[doc.tipo] || doc.tipo}
                    </span>
                    <span style={{ fontSize: 12, color: 'var(--gray-400)' }}>
                      {formatFecha(doc.creadoEn)}
                    </span>
                  </div>
                  <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--gray-800)',
                    whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {doc.titulo}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--gray-400)', marginTop: 2 }}>
                    Generado por: {doc.nombre || doc.usuario}
                  </div>
                </div>
                <span style={{ color: 'var(--gray-400)', fontSize: 18, flexShrink: 0 }}>
                  {selected?.id === doc.id ? '▲' : '▼'}
                </span>
              </div>

              {selected?.id === doc.id && (
                <div style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--gray-200)' }}>
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 10 }}>
                    <button className="btn btn-outline btn-sm" onClick={e => {
                      e.stopPropagation()
                      navigator.clipboard.writeText(doc.contenido)
                    }}>Copiar texto</button>
                  </div>
                  <pre style={{
                    whiteSpace: 'pre-wrap', fontSize: 13, lineHeight: 1.9,
                    color: 'var(--gray-800)', fontFamily: 'inherit',
                    maxHeight: 500, overflowY: 'auto',
                    background: 'var(--gray-50)', borderRadius: 8,
                    padding: '1rem', border: '1px solid var(--gray-200)',
                  }}>
                    {doc.contenido}
                  </pre>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
