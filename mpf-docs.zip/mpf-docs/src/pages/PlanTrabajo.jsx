// src/pages/PlanTrabajo.jsx
import { useState } from 'react'
import { generarConIA } from '../lib/claude.js'
import ResultPanel from '../components/ResultPanel.jsx'

const today = new Date().toISOString().split('T')[0]

export default function PlanTrabajo({ session }) {
  const [loading, setLoading] = useState(false)
  const [result, setResult]   = useState('')

  const [codigo,     setCodigo]     = useState('')
  const [fecha,      setFecha]      = useState(today)
  const [supervisor, setSupervisor] = useState('')
  const [horaIn,     setHoraIn]     = useState('')
  const [horaFin,    setHoraFin]    = useState('')
  const [condiciones,setCondiciones]= useState('')
  const [obs,        setObs]        = useState('')
  const [equipos,    setEquipos]    = useState([
    { tipo: '', operador: '' },
    { tipo: '', operador: '' },
  ])
  const [actividades, setActividades] = useState(['', ''])

  function addEquipo()    { setEquipos([...equipos, { tipo: '', operador: '' }]) }
  function removeEquipo(i){ if (equipos.length > 1) setEquipos(equipos.filter((_,x)=>x!==i)) }
  function setEquipo(i, field, val) {
    setEquipos(equipos.map((e,x) => x===i ? {...e, [field]: val} : e))
  }

  function addAct()     { setActividades([...actividades, '']) }
  function removeAct(i) { if (actividades.length > 1) setActividades(actividades.filter((_,x)=>x!==i)) }
  function setAct(i, val){ setActividades(actividades.map((a,x) => x===i ? val : a)) }

  async function generar() {
    const actsValidas = actividades.filter(a => a.trim())
    if (!actsValidas.length) { alert('Agrega al menos una actividad.'); return }

    const eqStr = equipos.filter(e=>e.tipo||e.operador)
      .map(e=>`  • ${e.tipo||'Equipo'}: Operador ${e.operador||'por asignar'}`).join('\n')

    const prompt = `Transforma el siguiente borrador en un PLAN DE TRABAJO DIARIO profesional para obra minera.

DATOS:
- Plataforma/Código: ${codigo||'sin especificar'}
- Fecha: ${fecha}
- Supervisor a cargo: ${supervisor||'sin especificar'}
- Equipos:
${eqStr}
${condiciones ? '- Condiciones especiales: ' + condiciones : ''}
${horaIn  ? '- Hora inicio: '    + horaIn  : ''}
${horaFin ? '- Hora término: '   + horaFin : ''}

ACTIVIDADES DEL DÍA:
${actsValidas.map((a,i)=>`${i+1}. ${a}`).join('\n')}

${obs ? 'OBSERVACIONES: ' + obs : ''}

Redacta el plan completo con estructura formal, numeración clara y lenguaje técnico. Corrige errores ortográficos. Incluye encabezado, cuerpo y cierre. El resultado debe estar listo para presentar al mandante Río Tinto.`

    setResult('')
    setLoading(true)
    try {
      await generarConIA(prompt, chunk => setResult(r => r + chunk))
    } catch(e) {
      alert('Error al generar: ' + e.message)
    }
    setLoading(false)
  }

  return (
    <div>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ fontSize: 22, fontWeight: 600, marginBottom: 4 }}>Plan de Trabajo Diario</h1>
        <p style={{ color: 'var(--gray-600)', fontSize: 14 }}>
          Completa el formulario con los datos del día y genera el documento formal automáticamente.
        </p>
      </div>

      {/* Identificación */}
      <div className="card mb-4">
        <div className="card-title">Identificación</div>
        <div className="grid-3 mb-3">
          <div>
            <label>Plataforma / Código</label>
            <input value={codigo} onChange={e=>setCodigo(e.target.value)} placeholder="NCEH-022"/>
          </div>
          <div>
            <label>Fecha</label>
            <input type="date" value={fecha} onChange={e=>setFecha(e.target.value)}/>
          </div>
          <div>
            <label>Supervisor a cargo</label>
            <input value={supervisor} onChange={e=>setSupervisor(e.target.value)} placeholder="Nombre del supervisor"/>
          </div>
        </div>
        <div className="grid-2">
          <div>
            <label>Hora inicio</label>
            <input value={horaIn} onChange={e=>setHoraIn(e.target.value)} placeholder="08:00"/>
          </div>
          <div>
            <label>Hora término</label>
            <input value={horaFin} onChange={e=>setHoraFin(e.target.value)} placeholder="18:30"/>
          </div>
        </div>
      </div>

      {/* Equipos */}
      <div className="card mb-4">
        <div className="card-title">Equipos y Operadores</div>
        {equipos.map((eq, i) => (
          <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'flex-end' }}>
            <div style={{ flex: 1 }}>
              {i === 0 && <label>Tipo de equipo</label>}
              <input value={eq.tipo} onChange={e=>setEquipo(i,'tipo',e.target.value)}
                placeholder="Excavadora 56"/>
            </div>
            <div style={{ flex: 1 }}>
              {i === 0 && <label>Operador</label>}
              <input value={eq.operador} onChange={e=>setEquipo(i,'operador',e.target.value)}
                placeholder="Nombre operador"/>
            </div>
            <button className="btn btn-danger btn-sm" onClick={()=>removeEquipo(i)}
              style={{ marginBottom: 0, flexShrink: 0 }}>×</button>
          </div>
        ))}
        <button className="btn btn-outline btn-sm" onClick={addEquipo} style={{ marginTop: 4 }}>
          + Agregar equipo
        </button>
      </div>

      {/* Condiciones */}
      <div className="card mb-4">
        <div className="card-title">Condiciones Especiales del Área</div>
        <textarea value={condiciones} onChange={e=>setCondiciones(e.target.value)} rows={3}
          placeholder="Ej: Presencia de empresa Biomapu con monitoreo paleontológico cada 30 min. Área crítica por hallazgo de fósiles..."/>
      </div>

      {/* Actividades */}
      <div className="card mb-4">
        <div className="card-title">Actividades del Día</div>
        {actividades.map((act, i) => (
          <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'flex-start' }}>
            <div style={{
              flexShrink: 0, width: 24, height: 36, display: 'flex',
              alignItems: 'center', justifyContent: 'center',
              fontSize: 12, fontWeight: 600, color: 'var(--gray-400)',
            }}>{i+1}</div>
            <textarea value={act} onChange={e=>setAct(i,e.target.value)} rows={2}
              style={{ flex: 1 }}
              placeholder="Describe la actividad con tus palabras, sin preocuparte del estilo..."/>
            <button className="btn btn-danger btn-sm" onClick={()=>removeAct(i)}
              style={{ marginTop: 6, flexShrink: 0 }}>×</button>
          </div>
        ))}
        <button className="btn btn-outline btn-sm" onClick={addAct} style={{ marginTop: 4 }}>
          + Agregar actividad
        </button>
      </div>

      {/* Observaciones */}
      <div className="card mb-4">
        <div className="card-title">Observaciones Adicionales (opcional)</div>
        <textarea value={obs} onChange={e=>setObs(e.target.value)} rows={2}
          placeholder="Cualquier información relevante adicional..."/>
      </div>

      <button className="btn btn-primary btn-lg" onClick={generar} disabled={loading}>
        {loading
          ? <><span className="dots"><span className="dot"/><span className="dot"/><span className="dot"/></span>&nbsp; Generando documento...</>
          : '✦ Generar documento profesional'
        }
      </button>

      <ResultPanel
        texto={result} tipo="plan"
        titulo={`Plan de Trabajo – ${codigo||'Sin código'} – ${fecha}`}
        session={session}
      />
    </div>
  )
}
