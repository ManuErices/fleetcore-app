// src/pages/Login.jsx
import { useState } from 'react'
import { login } from '../lib/auth.js'

export default function Login({ onLogin }) {
  const [usuario, setUsuario] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError]     = useState('')
  const [loading, setLoading] = useState(false)

  function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setLoading(true)
    setTimeout(() => {
      const res = login(usuario, password)
      if (res.ok) onLogin(res.session)
      else setError(res.error)
      setLoading(false)
    }, 400)
  }

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center',
      justifyContent: 'center', padding: '1rem',
      background: 'linear-gradient(135deg, #0f2035 0%, #1a3a5c 60%, #1e4976 100%)',
    }}>
      <div style={{ width: '100%', maxWidth: 380 }}>

        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            width: 64, height: 64, background: 'rgba(255,255,255,.1)',
            borderRadius: 16, marginBottom: 16, border: '1px solid rgba(255,255,255,.15)',
          }}>
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
              <path d="M16 3L28 8v8c0 7-5.5 12.5-12 14C9.5 28.5 4 23 4 16V8L16 3z" fill="rgba(255,255,255,.2)" stroke="rgba(255,255,255,.6)" strokeWidth="1.5"/>
              <text x="16" y="21" textAnchor="middle" fill="white" fontSize="9" fontWeight="700" fontFamily="system-ui">MPF</text>
            </svg>
          </div>
          <h1 style={{ color: '#fff', fontSize: 22, fontWeight: 600, marginBottom: 4 }}>
            MPF Documentos
          </h1>
          <p style={{ color: 'rgba(255,255,255,.55)', fontSize: 13 }}>
            Sistema de redacción profesional
          </p>
        </div>

        {/* Card */}
        <div style={{
          background: '#fff', borderRadius: 16, padding: '2rem',
          boxShadow: '0 25px 50px rgba(0,0,0,.35)',
        }}>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label>Usuario</label>
              <input
                type="text" value={usuario} autoComplete="username"
                onChange={e => setUsuario(e.target.value)}
                placeholder="Ingresa tu usuario"
                required
              />
            </div>
            <div style={{ marginBottom: error ? 12 : 20 }}>
              <label>Contraseña</label>
              <input
                type="password" value={password} autoComplete="current-password"
                onChange={e => setPassword(e.target.value)}
                placeholder="Ingresa tu contraseña"
                required
              />
            </div>

            {error && (
              <div style={{
                background: '#fef2f2', border: '1px solid #fecaca',
                borderRadius: 8, padding: '10px 12px',
                color: '#dc2626', fontSize: 13, marginBottom: 16,
              }}>
                {error}
              </div>
            )}

            <button className="btn btn-primary btn-lg" type="submit" disabled={loading}>
              {loading
                ? <><span className="dots"><span className="dot"/><span className="dot"/><span className="dot"/></span> Verificando...</>
                : 'Ingresar al sistema'
              }
            </button>
          </form>
        </div>

        <p style={{ textAlign: 'center', color: 'rgba(255,255,255,.35)', fontSize: 12, marginTop: 20 }}>
          MPF Ingeniería Civil SPA · Proyecto Río Tinto
        </p>
      </div>
    </div>
  )
}
