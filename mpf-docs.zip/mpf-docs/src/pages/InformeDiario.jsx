// src/pages/InformeDiario.jsx
import { useState } from 'react'
import { generarConIA } from '../lib/claude.js'
import ResultPanel from '../components/ResultPanel.jsx'

const today = new Date().toISOString().split('T')[0]

export default function InformeDiario({ session }) {
  const [loading, setLoading] = useState(false)
  const [result, setResult]   = useState('')

  const [fecha,      setFecha]      = useState(today)
  const [sector,     setSector]     = useState('')
  const [supervisor, setSupervisor] = useState('')
  const [clima,      setClima]      = useState('')
  const [trabajos,   setTrabajos]   = useState('')
  const [avance,     setAvance]     = useState('')
  const [horas,      setHoras]      = useState('')
  const [incidentes, setIncidentes] = useState('')

  async function generar() {
    if (!trabajos.trim()) { alert('Describe los trabajos ejecutados.'); return }

    const prompt = `Transforma el siguiente borrador en un INFORME DIARIO DE OBRAS formal y profesional para el mandante Río Tinto Mining.

DATOS:
- Fecha: ${fecha}
- Plataforma/Sector: ${sector||'sin especificar'}
- Supervisor: ${supervisor||'sin especificar'}
- Condiciones climáticas: ${clima||'sin especificar'}
${avance ? '- Avance del día: ' + avance : ''}
${horas  ? '- Horas efectivas trabajadas: ' + horas : ''}

TRABAJOS EJECUTADOS (borrador):
${trabajos}

INCIDENTES Y OBSERVACIONES:
${incidentes||'Sin incidentes reportados durante la jornada.'}

Redacta el informe completo con encabezado formal, secciones bien estructuradas, sin errores ortográficos y con lenguaje técnico apropiado para obra minera. El resultado debe estar listo para entregar al mandante.`

    setResult('')
    setLoading(true)
    try {
      await generarConIA(prompt, chunk => setResult(r => r + chunk))
    } catch(e) {
      alert('Error: ' + e.message)
    }
    setLoading(false)
  }

  return (
    <div>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ fontSize: 22, fontWeight: 600, marginBottom: 4 }}>Informe Diario de Obras</h1>
        <p style={{ color: 'var(--gray-600)', fontSize: 14 }}>
          Escribe el resumen del día con tus palabras. La IA genera el informe formal.
        </p>
      </div>

      {/* Datos generales */}
      <div className="card mb-4">
        <div className="card-title">Datos Generales</div>
        <div className="grid-2 mb-3">
          <div>
            <label>Fecha</label>
            <input type="date" value={fecha} onChange={e=>setFecha(e.target.value)}/>
          </div>
          <div>
            <label>Plataforma / Sector</label>
            <input value={sector} onChange={e=>setSector(e.target.value)} placeholder="NCEH-022"/>
          </div>
        </div>
        <div className="grid-2">
          <div>
            <label>Supervisor</label>
            <input value={supervisor} onChange={e=>setSupervisor(e.target.value)} placeholder="Nombre supervisor"/>
          </div>
          <div>
            <label>Condiciones climáticas</label>
            <input value={clima} onChange={e=>setClima(e.target.value)} placeholder="Ej: Despejado, viento moderado"/>
          </div>
        </div>
      </div>

      {/* Trabajos */}
      <div className="card mb-4">
        <div className="card-title">Resumen de Trabajos Ejecutados</div>
        <div style={{
          background: 'var(--gray-50)', border: '1px solid var(--gray-200)',
          borderRadius: 8, padding: '10px 12px', marginBottom: 10,
          fontSize: 12, color: 'var(--gray-600)',
        }}>
          💡 Escribe sin preocuparte de la redacción. La IA corregirá y formalizará el texto.
        </div>
        <textarea value={trabajos} onChange={e=>setTrabajos(e.target.value)} rows={6}
          placeholder="Ej: Se siguio trabajando en la plataforma con las 2 excavadoras y el bulldozer. El bulldozer empujo material para dar ancho y la excavadora 56 hizo terraza. Tuvimos que parar 3 veces por el monitoreo de fosiles, aprox 20 min cada parada..."/>
      </div>

      {/* Avance */}
      <div className="card mb-4">
        <div className="card-title">Avance y Rendimiento</div>
        <div className="grid-2">
          <div>
            <label>Avance estimado del día</label>
            <input value={avance} onChange={e=>setAvance(e.target.value)} placeholder="Ej: 60% de la plataforma"/>
          </div>
          <div>
            <label>Horas efectivas trabajadas</label>
            <input value={horas} onChange={e=>setHoras(e.target.value)} placeholder="Ej: 7,5 hrs efectivas"/>
          </div>
        </div>
      </div>

      {/* Incidentes */}
      <div className="card mb-4">
        <div className="card-title">Incidentes / Observaciones de Seguridad</div>
        <textarea value={incidentes} onChange={e=>setIncidentes(e.target.value)} rows={3}
          placeholder="Detenciones, problemas técnicos, observaciones de seguridad, etc. Si no hubo, dejar en blanco."/>
      </div>

      <button className="btn btn-primary btn-lg" onClick={generar} disabled={loading}>
        {loading
          ? <><span className="dots"><span className="dot"/><span className="dot"/><span className="dot"/></span>&nbsp; Generando informe...</>
          : '✦ Generar informe profesional'
        }
      </button>

      <ResultPanel
        texto={result} tipo="informe"
        titulo={`Informe Diario – ${sector||'Sin sector'} – ${fecha}`}
        session={session}
      />
    </div>
  )
}
